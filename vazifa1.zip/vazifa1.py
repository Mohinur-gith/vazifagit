import math as m
x = float(input("x = "))
y = float(input("y = "))
z = float(input("z = "))
b = m.pow(y,m.pow(m.fabs(x),(1/3)))+m.pow(m.cos(y),3)*\
    abs(x-y)*(1+(m.pow(m.sin(z),2)/m.sqrt(x+y)))/(m.exp(m.fabs(x-y))+x/2)
print("b = ",b)